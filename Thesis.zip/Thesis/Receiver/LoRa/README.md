# Receiver

The following commands are available:

```
./main sender "message" (Send a packet)
./main receive (Receive a packet)
./main datarate (Measure the data rate)
./main rtt (Measure the round trip time)
./main filereceive (Receive a png file)
./main per (Measure the packet error rate)
./main command (Receive control command)
```
