# Sender

The following commands are available:

```
./main sender "message" (Send a packet)
./main receive (Receive a packet)
./main rtt (Respond on a ping message so the receiver is able to measure the round trip time)
./main filesend (Send a a png file)
./main per (Transmit unique message with sequence number so the receiver is able to determine the packet error rate)
./main command (Send control command)
```
