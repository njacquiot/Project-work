#ifndef _config_h_
#define _config_h_

#define  CFG_sx1276_radio 1
#define CFG_eu868 1
//#define CFG_us915 1

#define US_PER_OSTICK 50
//#define  OSTICKS_PER_SEC 20000

#endif

